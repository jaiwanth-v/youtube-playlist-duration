# Use:

Webstore : https://chrome.google.com/webstore/detail/youtube-playlist-duration/pmaemkjbelibcgknodkoeggkohmhdnbb?hl=en&authuser=1

# Features

This extension works with any number of videos.

Added a feature for the user to set the index of starting and ending video.

If the number of videos in a playlist are more than 100, just scroll down to get complete duration.(As youtube renders only 100 videos for the first time page loads.)

